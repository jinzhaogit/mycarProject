window.onload=function(){
	(function(){
		$('submit').onclick=function(){
			var uname=$('uname').value;
			var upwd=$('upwd').value;
			var url="../../php/loginRegist/login.php?uname="+uname+"&upwd="+upwd;
			ajax(url,"",'get')
			.then(res=>{
				if(res=='1'){
					msgWin('登陆成功');
					if($('rem').checked) setCookie('uname',uname,3);
					location.href="../index.html";
				}
				else msgWin('账号或者密码不正确');
			})
		}
	})();
}
